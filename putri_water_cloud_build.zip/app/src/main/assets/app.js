const cfg = window.PUTRI_CONFIG || {};
const configured = cfg.SUPABASE_URL && cfg.SUPABASE_URL.startsWith('https://') && !cfg.SUPABASE_URL.includes('GANTI_') && cfg.SUPABASE_PUBLISHABLE_KEY && !cfg.SUPABASE_PUBLISHABLE_KEY.includes('GANTI_');
const db = configured ? window.supabase.createClient(cfg.SUPABASE_URL,cfg.SUPABASE_PUBLISHABLE_KEY) : null;
const $ = id => document.getElementById(id);
$('customerTab').onclick=()=>show('customer');
$('adminTab').onclick=()=>show('admin');
function show(which){$('customer').hidden=which!=='customer';$('admin').hidden=which!=='admin';$('customerTab').classList.toggle('active',which==='customer');$('adminTab').classList.toggle('active',which==='admin')}
function setup(){if(!db){$('orderResult').innerHTML='<p class="error">Aplikasi belum tersambung ke server. Admin perlu mengisi konfigurasi Supabase terlebih dahulu.</p>';}}
$('orderForm').addEventListener('submit',async e=>{
 e.preventDefault(); if(!db){setup();return}
 const orderCode='PW-'+Math.random().toString(36).slice(2,10).toUpperCase();\n const payload={order_code:orderCode,customer_name:$('name').value.trim(),phone:$('phone').value.trim(),address:$('address').value.trim(),gallon_qty:Number($('qty').value),notes:$('notes').value.trim()||null};
 if(!payload.customer_name||!payload.phone||!payload.address||payload.gallon_qty<1){return}
 $('orderResult').textContent='Mengirim pesanan...';
 const {error}=await db.from('orders').insert(payload);
 if(error){$('orderResult').innerHTML='<p class="error">Pesanan belum terkirim: '+escapeHtml(error.message)+'</p>';return}
 $('orderResult').innerHTML='<div class="success"><b>Pesanan terkirim!</b><br>Kode pesanan: <b>'+escapeHtml(orderCode)+'</b><br>Simpan kode ini untuk referensi saat menghubungi admin.</div>';
 $('orderForm').reset();$('qty').value=1;
});
$('loginForm').addEventListener('submit',async e=>{
 e.preventDefault();if(!db){$('adminMsg').textContent='Konfigurasi server belum diisi.';return}
 const {error}=await db.auth.signInWithPassword({email:$('email').value,password:$('password').value});
 if(error){$('adminMsg').textContent='Login gagal: '+error.message;return}
 $('adminMsg').textContent='';$('adminPanel').hidden=false;loadOrders();
});
$('logout').onclick=async()=>{await db.auth.signOut();$('adminPanel').hidden=true;$('orders').innerHTML='';};
async function loadOrders(){
 const {data,error}=await db.from('orders').select('*').order('created_at',{ascending:false}).limit(100);
 if(error){$('orders').textContent='Tidak dapat memuat pesanan: '+error.message;return}
 $('orders').innerHTML=data.map(o=>`<article class="order"><b>${escapeHtml(o.customer_name)}</b> • ${o.gallon_qty} galon<br><small>${escapeHtml(o.phone)} · ${escapeHtml(o.address)}<br>${new Date(o.created_at).toLocaleString('id-ID')} · ${escapeHtml(o.order_code)}</small><p>${escapeHtml(o.notes||'')}</p><label>Status<select data-id="${o.id}"><option ${o.status==='baru'?'selected':''} value="baru">Baru</option><option ${o.status==='diproses'?'selected':''} value="diproses">Diproses</option><option ${o.status==='diantar'?'selected':''} value="diantar">Diantar</option><option ${o.status==='selesai'?'selected':''} value="selesai">Selesai</option><option ${o.status==='dibatalkan'?'selected':''} value="dibatalkan">Dibatalkan</option></select></label></article>`).join('')||'Belum ada pesanan.';
 document.querySelectorAll('#orders select').forEach(s=>s.onchange=async()=>{const {error}=await db.from('orders').update({status:s.value}).eq('id',s.dataset.id);if(error)alert('Gagal memperbarui: '+error.message);else loadOrders();});
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
if(!configured)setup();
