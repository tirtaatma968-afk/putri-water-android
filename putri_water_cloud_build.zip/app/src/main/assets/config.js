// Isi setelah proyek Supabase PUTRI WATER dibuat.
// Gunakan publishable key, JANGAN gunakan service_role/secret key.
window.PUTRI_CONFIG = {
  SUPABASE_URL: "https://GANTI_PROJECT_REF.supabase.co",
  SUPABASE_PUBLISHABLE_KEY: "GANTI_DENGAN_PUBLISHABLE_KEY"
};
