# PUTRI WATER — Starter APK

Paket awal aplikasi Android pelanggan + admin. Ini adalah **source project**, belum APK siap instal.
Aplikasi memakai satu backend Supabase agar pesanan pelanggan dapat muncul di dashboard admin.

## Fitur tahap awal
- Form pemesanan on-demand: nama, nomor WhatsApp, alamat, jumlah galon, catatan.
- Kode pesanan otomatis.
- Dashboard admin: login, melihat pesanan terbaru, mengubah status.
- Refresh/realtime setelah konfigurasi backend.

## Sebelum dipakai sungguhan
1. Buat proyek Supabase khusus PUTRI WATER.
2. Jalankan `supabase/schema.sql` di SQL Editor.
3. Ambil Project URL dan publishable key dari Supabase.
4. Isi `SUPABASE_URL` dan `SUPABASE_PUBLISHABLE_KEY` di `app/src/main/assets/config.js`.
5. Buat akun admin melalui Supabase Auth, lalu masukkan UUID admin ke tabel `admin_users`.
6. Build APK melalui Android Studio (Build > Build Bundle(s) / APK(s) > Build APK(s)).

**Penting:** jangan pernah memasukkan `service_role` / secret key ke aplikasi Android.
Schema ini memakai RLS dan hanya admin yang terdaftar yang boleh membaca/mengubah pesanan.
Pemesanan publik dapat membuat pesanan; status pesanan tidak dibuka untuk publik pada tahap starter ini.

## Build
Buka folder ini melalui Android Studio. Gunakan JDK 17 dan Android Gradle Plugin yang ditentukan di project.
Pilih Build > Build APK(s). APK debug akan muncul di `app/build/outputs/apk/debug/`.

## Catatan
Ini fondasi tahap 1. Sebelum distribusi ke pelanggan, perlu uji perangkat, kebijakan privasi, validasi nomor, proteksi spam/rate limit, dan mekanisme pelanggan mengecek status pesanan (misalnya kode rahasia atau OTP).
