-- PUTRI WATER starter schema. Run in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  order_code text not null unique default ('PW-' || upper(substr(encode(gen_random_bytes(5),'hex'),1,8))),
  customer_name text not null check (char_length(customer_name) between 1 and 80),
  phone text not null check (char_length(phone) between 8 and 20),
  address text not null check (char_length(address) between 5 and 300),
  gallon_qty integer not null check (gallon_qty between 1 and 100),
  notes text,
  status text not null default 'baru' check (status in ('baru','diproses','diantar','selesai','dibatalkan')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.admin_users enable row level security;
alter table public.orders enable row level security;

-- Admin membership is managed only by trusted project owner via SQL editor.
revoke all on public.admin_users from anon, authenticated;
grant select on public.admin_users to authenticated;
create policy "Admins can verify own membership"
on public.admin_users for select to authenticated
using (user_id = (select auth.uid()));

grant insert on public.orders to anon, authenticated;
grant select, update on public.orders to authenticated;

create policy "Public can submit an order"
on public.orders for insert to anon, authenticated
with check (
  status = 'baru'
  and customer_name is not null
  and phone is not null
  and address is not null
  and gallon_qty between 1 and 100
);

create policy "Registered admins can view orders"
on public.orders for select to authenticated
using (exists (
  select 1 from public.admin_users a
  where a.user_id = (select auth.uid())
));

create policy "Registered admins can update orders"
on public.orders for update to authenticated
using (exists (
  select 1 from public.admin_users a
  where a.user_id = (select auth.uid())
))
with check (exists (
  select 1 from public.admin_users a
  where a.user_id = (select auth.uid())
));

-- Add the admin UUID after creating the admin account in Supabase Auth:
-- insert into public.admin_users(user_id) values ('PASTE-ADMIN-USER-UUID-HERE');
